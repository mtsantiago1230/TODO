import React from 'react';
import './TodoSearch.css';

function TodoSearch({ searchValue, setSearchValue })
{
  //-- funcion para setear el valor del input
  const onSearchValueChange = (event) => {
    //-- seteamos el valor digitado en el input
    setSearchValue(event.target.value);
  };

  return [
    <input
      className="TodoSearch"
      placeholder="Escribe aquí"
      value={searchValue} //-- componente controlado, para validaciones
      // disabled={searchValue.length>8}
      onChange={onSearchValueChange}
    />,
  ];
}

export { TodoSearch };