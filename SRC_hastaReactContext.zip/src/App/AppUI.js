import React from 'react';
import { TodoCounter } from '../TodoCounter';
import { TodoSearch } from '../TodoSearch';
import { TodoList } from '../TodoList';
import { TodoItem } from '../TodoItem';
import { CreateTodoButton } from '../CreateTodoButton';

function AppUI(props)
{
  return [
      //-- contador
      <TodoCounter
        total={props.totalTodos}
        completed={props.completedTodos}
      />,

      //-- barra de busqueda
      <TodoSearch
        searchValue={props.searchValue}
        setSearchValue={props.setSearchValue}
      />,

      //-- lista de tareas
      <TodoList>

        {/* Mostramos un mensaje en caso de que ocurra algún error */}
        {props.error && <p>Desespérate, hubo un error...</p>}
        {/* cuando la aplicación está cargando los datos */}
        {props.loading && <p>Estamos cargando, no desesperes...</p>}
        {/* Si terminó de cargar y no existen tareas */}
        {(!props.loading && !props.searchedTodos.length) && <p>¡Crea tu primer TODO!</p>}
        

        {props.searchedTodos.map((todo,index) => (
          <TodoItem
            key={index.toString()}
            value={index}
            text={todo.text}
            completed={todo.completed}
            onComplete={() => props.completeTodo(todo.text)}
            onDelete={() => props.deleteTodo(todo.text)}
          />
        ))}
      </TodoList>,

      //-- btn crear tarea
      <CreateTodoButton />
  ];
}

export { AppUI };