import React from 'react';
import './TodoItem.css';

function TodoItem(props) {
  return (
    //-- creamos lista de tarea
    //-- validamos en los span/p si esta completada la tarea
    //-- no funcion el KEY
    <li className="TodoItem" key={props.value}>
      <span
        className={`Icon Icon-check ${props.completed && 'Icon-check--active'}`}
        onClick={props.onComplete}
      >
        √
      </span>
      <p className={`TodoItem-p ${props.completed && 'TodoItem-p--complete'}`}>
        {props.text}
      </p>
      <span
        className="Icon Icon-delete"
        onClick={props.onDelete}
      >
        X
      </span>
    </li>
  );
}

export { TodoItem };